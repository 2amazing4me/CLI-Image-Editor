#include "struct.h"

void read_command(char **str, char **command);

void task_processor(pixel ***arr, area *active, int *img_type, int *lin,
					int *col, int *max_val_pixel);
